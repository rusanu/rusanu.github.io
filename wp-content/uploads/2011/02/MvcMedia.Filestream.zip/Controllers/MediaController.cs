﻿//****************************************************************
//   Copyright 2010 Remus Rusanu  http://rusanu.com
//
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.
//****************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcMedia.Models;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace MvcMedia.Controllers
{
    /// <summary>
    /// Controller for the Media folder
    /// </summary>
    public class MediaController : Controller
    {
        /// <summary>
        /// The media repository used to get the files to upload and download
        /// </summary>
        public IMediaRepository Repository { get; set; }

        /// <summary>
        /// CTOR
        /// The Repository is hard-coded to the SQL based implementation
        /// Use an IoC framework to customize this
        /// </summary>
        public MediaController()
        {
            Repository = new FileStreamMediaRepository();
                //new SqlMediaRepository();
        }

        /// <summary>
        /// Upoload handler. 
        /// Handles an HTTP POST request on the http://site/Media URL
        /// Expects that the post data contains the file to be uploaded
        /// The return redirects the user to the newly uploaded file URL
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Index()
        {
            string fileName;
            Repository.PostFile(Request.Files[0], out fileName);
            return RedirectToRoute("Media", new { filename = fileName });
        }

        /// <summary>
        /// Download handler
        /// Handles the HTTP GET request on the http://site/Media/filename URL
        /// </summary>
        /// <param name="fileName">The file do download</param>
        /// <returns>MVC Action Result for the download</returns>
        [HttpGet]
        public ActionResult GetFile(string fileName)
        {
            FileDownloadModel model;
            if (false == Repository.GetFileByName(
                fileName, 
                out model))
            {
                return new HttpNotFoundResult
                {
                    StatusDescription = String.Format(
                        "File {0} not found", 
                        fileName)
                };
            }

            if (null != model.ContentCoding)
            {
                Response.AddHeader(
                    "Content-Encoding", 
                    model.ContentCoding);
            }
            Response.AddHeader(
                "Content-Length", 
                model.ContentLength.ToString ());

            Response.BufferOutput = false;

            return new FileStreamResult(
                model.Content, 
                model.ContentType);
        }
    }
}
