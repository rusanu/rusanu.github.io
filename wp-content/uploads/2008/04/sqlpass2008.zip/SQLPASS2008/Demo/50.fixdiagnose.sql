/*
D  29976 REMUSR10\Katmai diag_initiator  Could not validate the SEND permission
of user dbo on service targetService due to exception The server principal "REMU
SR10\Remus" is not able to access the database "diag_target" under the current s
ecurity context.
D  29984 REMUSR10\Katmai diag_initiator  Database diag_initiator is required to
have the TRUSTWORTHY option set to deliver messages to a different database if n
o dialog security is configured using a REMOTE SERVICE BINDING
*/

:connect REMUSR10\Katmai

alter database [diag_initiator]
	set trustworthy on;
go	