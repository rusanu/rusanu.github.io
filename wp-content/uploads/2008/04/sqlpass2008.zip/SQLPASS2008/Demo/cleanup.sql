:connect REMUSR10

use master;
go

if exists (select * from sys.service_broker_endpoints)
begin
	drop endpoint [BROKER];
end
go

if exists (select * from sys.certificates where name = 'REMUSR10')
begin
	drop certificate REMUSR10
end
go

if exists (select * from sys.certificates where name = 'REMUSR10_1')
begin
	drop certificate REMUSR10_1
end
go

if exists (select * from sys.certificates where name = 'REMUSR10_2')
begin
	drop certificate REMUSR10_2
end
go

if exists (select * from sys.certificates where name = 'REMUSR10_3')
begin
	drop certificate REMUSR10_3
end



if db_id('slm_init') is not null
begin	
	alter database slm_init set single_user with rollback immediate;
	drop database slm_init;
end	
go


:connect REMUSR10\KATMAI
use master;
go

if exists (select * from sys.service_broker_endpoints)
begin
	drop endpoint [BROKER];
end
go

if exists (select * from sys.certificates where name = 'REMUSR10')
begin
	drop certificate REMUSR10
end
go

if exists (select * from sys.certificates where name = 'REMUSR10_1')
begin
	drop certificate REMUSR10_1
end
go

if exists (select * from sys.certificates where name = 'REMUSR10_2')
begin
	drop certificate REMUSR10_2
end
go

if exists (select * from sys.certificates where name = 'REMUSR10_3')
begin
	drop certificate REMUSR10_3
end
go


if db_id('slm_target') is not null
begin	
	alter database slm_target set single_user with rollback immediate;
	drop database slm_target;
end	
go

if db_id('demo_priority') is not null
begin	
	alter database demo_priority set single_user with rollback immediate;
	drop database demo_priority;
end	
go

if db_id('diag_initiator') is not null
begin	
	alter database diag_initiator set single_user with rollback immediate;
	drop database diag_initiator;
end	
go

if db_id('diag_target') is not null
begin	
	alter database diag_target set single_user with rollback immediate;
	drop database diag_target;
end	
go
