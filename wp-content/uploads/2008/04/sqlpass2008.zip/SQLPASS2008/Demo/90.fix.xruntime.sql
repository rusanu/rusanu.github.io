:connect REMUSR10

use slm_init;
go

-- change the certificate to be active_for_begin_dialog = off
--
alter certificate [signPriviledgedProcedure]
	with active for begin_dialog = off;
