:connect REMUSR10

use slm_init;
go

-- dbo is using code signing on a procedure
-- in order to allow a priviledged procedure 
-- to be executed by non-priviledged users
--

create table [PriviledgedTable] (
	ID int not null identity (1,1),
	[public_data] varchar(max),
	[secret_data] varchar(max));
go	

create procedure [usp_ViewPriviledgedTable]
	with execute as caller
as
begin
	select ID, [public_data] from [PriviledgedTable];
end
go

-- Certificate used for code signing. 
-- To avoid service problems in future 
-- the expiry_date is extended 100 years
--
create certificate [signPriviledgedProcedure]
	with subject = 'Sign usp_ViewPriviledgedTable',
	start_date = '2008-01-01',
	expiry_date = '2108-04-15';
go

add signature to dbo.[usp_ViewPriviledgedTable]
	by certificate [signPriviledgedProcedure];
go

create user [userViewPriviledgedTable] from certificate [signPriviledgedProcedure];
grant select on [PriviledgedTable] to [userViewPriviledgedTable];
go		
