:connect REMUSR10\KATMAI

use master;
go

create database demo_priority;
go

use demo_priority;
go

-- Create two contracts/message type, one normal 
-- and one for higher priority
--
create message type [normalMessage] validation = none;
create message type [importantMessage] validation = none;

create contract [normalContract]
	([normalMessage] sent by any);
create contract [importantContract]
	([importantMessage] sent by any);
go

-- create the priority rule for importantContract
--
create broker priority [importantContractPriority]
	for conversation set (
		contract_name = [importantContract], 
		priority_level = 6);
go

-- Create a service that implements both normal and priority contracts
--
create queue [priorityQueue];
create service [priorityService]
	on queue [priorityQueue]
	([normalContract],
	[importantContract]);
go	


-- create an initiator service for demo
--
create queue [initiatorQueue];
create service [initiatorService]
	on queue [initiatorQueue];
go

-- send a few normal messages
-- 
declare @h uniqueidentifier;
begin dialog conversation @h
	from service [initiatorService]
	to service 'priorityService', 'current database'
	on contract [normalContract]
	with encryption = off;
send on conversation @h 
	message type [normalMessage] 
	('Message 1');
go	

declare @h uniqueidentifier;
begin dialog conversation @h
	from service [initiatorService]
	to service 'priorityService', 'current database'
	on contract [normalContract]
	with encryption = off;
send on conversation @h 
	message type [normalMessage] 
	('Message 2');
go

declare @h uniqueidentifier;
begin dialog conversation @h
	from service [initiatorService]
	to service 'priorityService', 'current database'
	on contract [normalContract]
	with encryption = off;
send on conversation @h 
	message type [normalMessage] 
	('Message 3');
go

-- send an important message
--
declare @h uniqueidentifier;
begin dialog conversation @h
	from service [initiatorService]
	to service 'priorityService', 'current database'
	on contract [importantContract]
	with encryption = off;
send on conversation @h 
	message type [importantMessage] 
	('Message 4 Important');
go

-- Messages are enqueued in sent order
select cast(message_body as varchar(max)) from [priorityQueue];
go

-- RECEIVE will get the important message first
receive 
	cast(message_body as varchar(max)), *
	from [priorityQueue];
go
	
-- RECEIVE continues with normal priority message in order received	
receive 
	cast(message_body as varchar(max)), *
	from [priorityQueue];
go