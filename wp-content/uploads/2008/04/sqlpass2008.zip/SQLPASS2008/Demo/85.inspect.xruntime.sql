:connect REMUSR10

use slm_init;
go

select * from sys.certificates;
go