:connect REMUSR10\Katmai

use master;
go

create database [diag_initiator];
go

use [diag_initiator];
go

create queue [initQueue];
create service [initService] 
	on queue [initQueue];
go

:connect REMUSR10\Katmai

create database [diag_target];
go

use [diag_target];
go

create queue [targetQueue];
create service [targetService]
	on queue [targetQueue]
	([DEFAULT]);
go

:connect REMUSR10\Katmai

use [diag_initiator];
go

declare @h uniqueidentifier;
begin dialog conversation @h 
	from service [initService]
	to service N'targetService'
	with encryption = off;
send on conversation @h 
	('Delayed');
	
	