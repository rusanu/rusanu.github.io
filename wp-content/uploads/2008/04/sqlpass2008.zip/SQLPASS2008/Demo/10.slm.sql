:connect REMUSR10

use [master];
go

create database slm_init;
go

use slm_init;
go

create master key encryption by password ='SLM$DEMO1234';
go

-- Create the contract and message types used
--
create message type [slm_demo_message] validation = none;
create contract [slm_demo_contract] (
	[slm_demo_message] sent by any);
	
-- create the queue and service
create queue [slm_demo_init_queue];
create service [slm_demo_init_service]
	on queue [slm_demo_init_queue];
go


:connect REMUSR10\KATMAI

use [master];
go

create database slm_target;
go

use slm_target;
go

create master key encryption by password ='SLM$DEMO1234';
go


-- Create the contract and message types used
--
create message type [slm_demo_message] validation = none;
create contract [slm_demo_contract] (
	[slm_demo_message] sent by any);
	
-- create the queue and service
create queue [slm_demo_target_queue];
create service [slm_demo_target_service]
	on queue [slm_demo_target_queue] 
	([slm_demo_contract]);
go
