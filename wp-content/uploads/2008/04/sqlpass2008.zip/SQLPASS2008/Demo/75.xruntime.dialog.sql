:connect REMUSR10

-- Begin a dialog and send a message from initiator
--
use [slm_init];
go

declare @h uniqueidentifier;
begin transaction
begin dialog conversation @h
	from service [slm_demo_init_service]
	to service N'slm_demo_target_service'
	on contract [slm_demo_contract]
	with encryption = off;
send on conversation @h 
	message	type [slm_demo_message]
	('Hello, world!');
commit;
go

:connect REMUSR10\KATMAI

-- Wait for message to arrive at target and display the message
-- 
use slm_target;
go

declare @h uniqueidentifier;
declare @body varbinary(max);
declare @type sysname;

begin transaction;
waitfor (receive top(1)
	@h = conversation_handle,
	@type = message_type_name,
	@body = message_body
	from [slm_demo_target_queue]),
	timeout 5000;
select cast(@body as varchar(max)), @type;
commit;
go