:connect REMUSR10\Katmai

use master;
go

create database [diag_initiator];
go

use [diag_initiator];
go

create queue [initQueue];
create service [initService] 
	on queue [initQueue];
go

:connect REMUSR10\Katmai

create database [diag_target];
go

use [diag_target];
go

create queue [targetQueue];
create service [targetService]
	on queue [targetQueue]
	([DEFAULT]);
go
	